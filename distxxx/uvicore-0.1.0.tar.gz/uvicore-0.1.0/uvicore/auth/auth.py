class _Auth:
    pass
