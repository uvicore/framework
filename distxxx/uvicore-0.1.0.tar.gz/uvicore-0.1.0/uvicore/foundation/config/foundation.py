config = {

    'register_web_routes': False,
    'register_api_routes': False,
    'register_views': False,
    'register_commands': True,

}
