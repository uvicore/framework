from .server import Server
from .router import Router, Routes
#from fastapi_utils.cbv import cbv as controller
from .controller import cbv as controller
