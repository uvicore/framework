from fastapi import FastAPI

class Server(FastAPI):
    pass
    # def controller(self, *args, **kargs):
    #     return self.include_router(*args, **kargs)
